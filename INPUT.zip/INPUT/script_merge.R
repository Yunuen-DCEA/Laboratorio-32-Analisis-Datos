####################
#                  #
# Copiar todo esto #
#                  #
####################
# Hecho con gusto por Yunu�n Hern�ndez �lvarez (UAEH)


# LABORATORIO - MERGE



#Cargar paquetes
library(data.table)


#Cargar base de datos
choose.files()


#Crear variable
green.products <- read.csv("C:\\Users\\yunh_\\Desktop\\DOCTORADO\\4to. SEMESTRE\\AN�LISIS DE DATOS\\Tareas\\Laboratorios\\Lab 32 - Merge\\green products.csv")
all.products <- read.csv("C:\\Users\\yunh_\\Desktop\\DOCTORADO\\4to. SEMESTRE\\AN�LISIS DE DATOS\\Tareas\\Laboratorios\\Lab 32 - Merge\\COMPLETE_YEARS_PRODUCTS.csv")


#Leer elementos como una tabla de datos
green.products <- as.data.table(green.products)
all.products <- as.data.table(all.products)

#Hacer merge
merge.allproducts = merge(all.products, green.products, by="product_code")


#Unir todo (combinaci�n completa)
merge.full = merge(all.products, green.products, by="product_code", all.x = T)


#Exportar resultado
write.csv(merge.full, file = "merge.full.csv")

